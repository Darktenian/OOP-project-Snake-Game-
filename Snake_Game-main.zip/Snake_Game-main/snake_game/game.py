"""Game: runs the main loop and decides when the game starts and ends."""
import pygame

from . import settings
from .board import Board
from .food import Food
from .input_handler import InputHandler
from .scoreboard import ScoreBoard
from .snake import Snake


class Game:
    PLAYING, GAME_OVER = "playing", "game_over"

    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Snake")
        self.screen = pygame.display.set_mode((settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT))
        self.hud_surface = self.screen.subsurface((0, 0, settings.WINDOW_WIDTH, settings.HUD_HEIGHT))
        self.board_surface = self.screen.subsurface(
            (0, settings.HUD_HEIGHT, settings.BOARD_WIDTH, settings.BOARD_HEIGHT))
        self.font = pygame.font.SysFont("arial", 24)
        self.big_font = pygame.font.SysFont("arial", 48, bold=True)
        self.clock = pygame.time.Clock()
        self.board = Board()
        self.scoreboard = ScoreBoard()
        self.input = InputHandler()
        self.running = True
        self.new_round()

    # --- round control -------------------------------------------------
    def new_round(self):
        self.scoreboard.reset()
        self.snake = Snake(self.board.center())
        self.food = Food(self.board.random_free_cell(self.snake.body))
        self.state = self.PLAYING

    def step(self):
        """One game tick: move, eat, check collisions."""
        self.snake.update()
        if self.snake.position == self.food.position:
            self.snake.grow()
            self.scoreboard.register_food()
            new_cell = self.board.random_free_cell(self.snake.body)
            if new_cell is None:          # board is full: player wins, end round
                self.state = self.GAME_OVER
                return
            self.food.relocate(new_cell)
        if self.board.hits_wall(self.snake.position) or self.snake.hits_itself():
            self.state = self.GAME_OVER

    # --- main loop -----------------------------------------------------
    def run(self):
        while self.running:
            cmd = self.input.poll()
            if cmd.quit:
                break
            if self.state == self.PLAYING:
                if cmd.direction:
                    self.snake.turn(cmd.direction)
                self.step()
            elif cmd.key_pressed:
                self.new_round()
            self.draw()
            self.clock.tick(self.scoreboard.speed if self.state == self.PLAYING else 30)
        pygame.quit()

    def draw(self):
        self.board.draw(self.board_surface)
        self.food.draw(self.board_surface, self.board.cell_size)
        self.snake.draw(self.board_surface, self.board.cell_size)
        self.scoreboard.draw(self.hud_surface, self.font)
        if self.state == self.GAME_OVER:
            self._draw_game_over()
        pygame.display.flip()

    def _draw_game_over(self):
        overlay = pygame.Surface(self.board_surface.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        self.board_surface.blit(overlay, (0, 0))
        w, h = self.board_surface.get_size()
        lines = [(self.big_font, "GAME OVER", -50),
                 (self.font, f"Final score: {self.scoreboard.score}", 5),
                 (self.font, "Press any key to play again", 45)]
        for font, text, dy in lines:
            img = font.render(text, True, settings.TEXT_COLOR)
            self.board_surface.blit(img, img.get_rect(center=(w // 2, h // 2 + dy)))
