"""InputHandler: reads the arrow keys (and quit / restart keys)."""
from dataclasses import dataclass
from typing import Optional, Tuple

import pygame

from .snake import DOWN, LEFT, RIGHT, UP

KEY_TO_DIRECTION = {
    pygame.K_UP: UP, pygame.K_DOWN: DOWN, pygame.K_LEFT: LEFT, pygame.K_RIGHT: RIGHT,
    pygame.K_w: UP, pygame.K_s: DOWN, pygame.K_a: LEFT, pygame.K_d: RIGHT,
}


@dataclass
class Command:
    direction: Optional[Tuple[int, int]] = None
    quit: bool = False
    key_pressed: bool = False  # any key (used on the Game Over screen)


class InputHandler:
    def poll(self):
        cmd = Command()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                cmd.quit = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    cmd.quit = True
                cmd.key_pressed = True
                if event.key in KEY_TO_DIRECTION:
                    cmd.direction = KEY_TO_DIRECTION[event.key]
        return cmd
