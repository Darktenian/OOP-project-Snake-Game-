"""Food: holds its spot and moves to a new free box when eaten."""
import pygame

from . import settings
from .game_object import GameObject


class Food(GameObject):
    def update(self):
        pass  # food does not move by itself

    def relocate(self, new_position):
        self._position = new_position

    def draw(self, surface, cell_size):
        rect = self._cell_rect(self._position, cell_size)
        pygame.draw.circle(surface, settings.FOOD_COLOR, rect.center, cell_size // 2 - 3)
