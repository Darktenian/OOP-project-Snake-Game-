"""Abstraction: the base class every object on the board must follow."""
from abc import ABC, abstractmethod

import pygame


class GameObject(ABC):
    """Base class. Only says WHAT every object must do (update, draw)."""

    def __init__(self, position):
        self._position = position  # (col, row)

    @property
    def position(self):
        return self._position

    @abstractmethod
    def update(self):
        """Advance the object by one game step."""

    @abstractmethod
    def draw(self, surface, cell_size):
        """Draw the object onto the given surface."""

    @staticmethod
    def _cell_rect(cell, cell_size):
        return pygame.Rect(cell[0] * cell_size, cell[1] * cell_size, cell_size, cell_size)
