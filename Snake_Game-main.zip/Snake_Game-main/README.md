# Snake (OOP, Python + Pygame)

## Run
```bash
python -m venv .venv
.venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
python main.py
```

## Controls
Arrow keys / WASD to turn · any key to restart after Game Over · Esc to quit.

## Rules
Eat food: +10 points. Every 5 foods the level goes up and the snake gets faster.
Hitting a wall or your own body ends the round.

## Structure
```
snake-game/
├── main.py              # entry point
├── requirements.txt
├── snake_game/
│   ├── settings.py      # constants
│   ├── game_object.py   # GameObject (abstract base)
│   ├── snake.py         # Snake(GameObject)
│   ├── food.py          # Food(GameObject)
│   ├── board.py         # Board
│   ├── scoreboard.py    # ScoreBoard
│   ├── input_handler.py # InputHandler
│   └── game.py          # Game (main loop)
└── docs/class_diagram.md
```
