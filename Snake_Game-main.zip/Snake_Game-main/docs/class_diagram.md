```mermaid
classDiagram
    class GameObject {
        <<abstract>>
        #position
        +update()*
        +draw(surface, cell_size)*
    }
    class Snake {
        -body
        -direction
        +turn(direction)
        +grow()
        +hitsItself() bool
    }
    class Food {
        +relocate(position)
    }
    class Board {
        +cols
        +rows
        +hits_wall(cell) bool
        +random_free_cell(occupied)
    }
    class ScoreBoard {
        +score
        +level
        +register_food()
    }
    class InputHandler {
        +poll() Command
    }
    class Game {
        +run()
        +step()
        +new_round()
    }
    GameObject <|-- Snake
    GameObject <|-- Food
    Game o-- Board
    Game o-- Snake
    Game o-- Food
    Game o-- ScoreBoard
    Game o-- InputHandler
```
