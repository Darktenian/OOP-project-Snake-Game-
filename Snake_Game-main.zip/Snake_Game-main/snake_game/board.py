"""Board: knows the play-area size and where the walls are."""
import random

import pygame

from . import settings


class Board:
    def __init__(self, cols=settings.GRID_COLS, rows=settings.GRID_ROWS, cell_size=settings.CELL_SIZE):
        self.cols = cols
        self.rows = rows
        self.cell_size = cell_size

    def hits_wall(self, cell):
        x, y = cell
        return x < 0 or y < 0 or x >= self.cols or y >= self.rows

    def center(self):
        return (self.cols // 2, self.rows // 2)

    def random_free_cell(self, occupied):
        occupied = set(occupied)
        free = [(x, y) for x in range(self.cols) for y in range(self.rows) if (x, y) not in occupied]
        return random.choice(free) if free else None

    def draw(self, surface):
        surface.fill(settings.BG_COLOR)
        for x in range(0, self.cols * self.cell_size, self.cell_size):
            pygame.draw.line(surface, settings.GRID_COLOR, (x, 0), (x, self.rows * self.cell_size))
        for y in range(0, self.rows * self.cell_size, self.cell_size):
            pygame.draw.line(surface, settings.GRID_COLOR, (0, y), (self.cols * self.cell_size, y))
        pygame.draw.rect(surface, settings.WALL_COLOR, surface.get_rect(), width=4)  # walls
