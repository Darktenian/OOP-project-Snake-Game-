"""ScoreBoard: keeps the score and the level."""
import pygame

from . import settings


class ScoreBoard:
    def __init__(self):
        self.reset()

    def reset(self):
        self.score = 0
        self.foods_eaten = 0

    @property
    def level(self):
        return self.foods_eaten // settings.FOODS_PER_LEVEL + 1

    @property
    def speed(self):
        return settings.BASE_SPEED + (self.level - 1) * settings.SPEED_STEP

    def register_food(self):
        self.score += settings.POINTS_PER_FOOD
        self.foods_eaten += 1

    def draw(self, surface, font):
        surface.fill(settings.HUD_COLOR)
        text = font.render(f"Score: {self.score}     Level: {self.level}", True, settings.TEXT_COLOR)
        surface.blit(text, (15, (surface.get_height() - text.get_height()) // 2))
