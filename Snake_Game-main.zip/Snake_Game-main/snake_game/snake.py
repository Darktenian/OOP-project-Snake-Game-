"""The snake: moves, turns, grows and checks if it hit itself."""
import pygame

from . import settings
from .game_object import GameObject

UP, DOWN, LEFT, RIGHT = (0, -1), (0, 1), (-1, 0), (1, 0)


class Snake(GameObject):
    def __init__(self, start, length=settings.SNAKE_START_LENGTH):
        super().__init__(start)
        # Encapsulation: body/direction are private; use turn(), grow(), hits_itself().
        self.__body = [(start[0] - i, start[1]) for i in range(length)]  # head first
        self.__direction = RIGHT
        self.__pending_direction = RIGHT
        self.__grow_pending = 0

    @property
    def position(self):
        return self.__body[0]  # the head

    @property
    def body(self):
        return tuple(self.__body)  # read-only copy

    def turn(self, direction):
        """Turn the snake. A 180-degree reverse is ignored."""
        opposite = (-self.__direction[0], -self.__direction[1])
        if direction != opposite:
            self.__pending_direction = direction

    def grow(self):
        self.__grow_pending += 1

    def hitsItself(self):
        return self.__body[0] in self.__body[1:]

    hits_itself = hitsItself  # pythonic alias

    def update(self):
        self.__direction = self.__pending_direction
        head_x, head_y = self.__body[0]
        dx, dy = self.__direction
        self.__body.insert(0, (head_x + dx, head_y + dy))
        if self.__grow_pending > 0:
            self.__grow_pending -= 1
        else:
            self.__body.pop()

    def draw(self, surface, cell_size):
        for i, cell in enumerate(self.__body):
            color = settings.SNAKE_HEAD_COLOR if i == 0 else settings.SNAKE_COLOR
            pygame.draw.rect(surface, color, self._cell_rect(cell, cell_size).inflate(-2, -2), border_radius=6)
