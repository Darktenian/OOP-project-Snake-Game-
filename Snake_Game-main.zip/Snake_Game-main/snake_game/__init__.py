"""Snake game package (OOP design: GameObject, Snake, Food, Board, ScoreBoard, InputHandler, Game)."""
